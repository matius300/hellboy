<?php
header("HTTP/1.1 403 Forbidden");
$keyword = $_GET['file'];
//header("Location: https://look.udncoeln.com/offer?prod=2&ref=5185926");
header("Location: https://web.facebook.com/");
die();
?>
