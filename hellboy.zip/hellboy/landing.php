<?php
$acak = rand( 1, 4);
include('lp'.$acak.'/lp.php');
} ?> 

